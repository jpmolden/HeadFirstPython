# Cuddle App
## Python Web App for Cuddle Requests
<!--
[RTL_src](../hw7_digitalclock_clock/rtl_src/clock.sv)

[testbench](../hw7_digitalclock_clock/rtl_src/clock_tb.sv)

![Image](../hw7_digitalclock_clock/blockschem.png)
![Image](../hw7_digitalclock_clock/tbwaveform.PNG)
 -->
## Introduction:

...In

## Run the app
```
    C:\Users\johnp_000\Documents\GitHub\HeadFirstPython\chapter_5_webapp\webapp_cuddles>py -3 hello_flask.py
```
<!--
## Running the testbench
```
    ./doit clock_tb
```

## Testbench console/file output snippet
```
    # INFO: running for:             0 days,             0 hours,             0 mins,             2 seconds
    #   digit_4 = 1001111 decode: 1
    #   digit_3 = 0010010 decode: 2
    #   digit_2 = 1111100 decode: :  AM
    #   digit_1 = 0000001 decode: 0
    #   digit_0 = 0000001 decode: 0
    # INFO: running for:             0 days,            11 hours,            59 mins,            59 seconds
    #   digit_4 = 1001111 decode: 1
    #   digit_3 = 1001111 decode: 1
    #   digit_2 = 1111111 decode:    AM
    #   digit_1 = 0100100 decode: 5
    #   digit_0 = 0001100 decode: 9
    # INFO: running for:             0 days,            12 hours,             0 mins,             0 seconds
    #   digit_4 = 1001111 decode: 1
    #   digit_3 = 0010010 decode: 2
    #   digit_2 = 1111000 decode: :  PM
    #   digit_1 = 0000001 decode: 0
    #   digit_0 = 0000001 decode: 0
```
 -->
