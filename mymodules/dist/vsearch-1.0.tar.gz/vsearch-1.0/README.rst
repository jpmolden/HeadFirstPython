Using the setuptools distribution
=================

vsearch - Text searching
------------------
